# Gateway de atendimento IA — Espaço Solda

Um ponto de entrada único no seu domínio (`/api/*`) que alimenta o **agente de IA** (Claude):

| Rota | Para quê |
|---|---|
| `POST /api/chat` | Chat "Atendente virtual" do site |
| `GET/POST /api/whatsapp` | Webhook do WhatsApp Business (Cloud API da Meta) |
| `GET /api/health` | Mostra se IA/WhatsApp/aviso estão configurados (sem expor segredos) |

O agente: atende em português, **não inventa preço, estoque ou prazo**, coleta nome, telefone e itens,
registra o orçamento (aviso à equipe + botão de WhatsApp pronto) e **passa para uma pessoa** quando necessário.
Ele se apresenta como IA, nunca pede CPF/cartão/senha e ignora tentativas de mudar suas regras.

## 1. Como publicar (importante)
Funções **não rodam** em deploy por arrastar e soltar. Use um destes caminhos:
- **GitHub → Netlify (recomendado):** suba esta pasta para um repositório e conecte no Netlify
  (Add new site → Import from Git). O Netlify instala as dependências e publica as funções sozinho.
- **Netlify CLI:** `npm install` e depois `npx netlify deploy --prod` dentro desta pasta.

O site (HTML) continua funcionando sem as funções; nesse caso o chat mostra o botão de WhatsApp.

## 2. Variáveis de ambiente
Netlify → Site configuration → Environment variables. Lista completa em `.env.example`.
Mínimo para o chat funcionar: **`ANTHROPIC_API_KEY`** (crie em console.anthropic.com e **defina um limite
mensal de gasto** lá). Depois do deploy, abra `seudominio.com.br/api/health`: deve mostrar `"ia": true`.

## 3. WhatsApp (opcional, depois do site)
1. Crie um app em developers.facebook.com (tipo Business) e adicione o produto **WhatsApp**.
2. Use um número que **não esteja** no app WhatsApp comum (a Cloud API exige o número dedicado).
3. Em *Configuration → Webhook*: URL `https://seudominio.com.br/api/whatsapp`, token = `WHATSAPP_VERIFY_TOKEN`;
   assine o campo **messages**.
4. Preencha `WHATSAPP_APP_SECRET`, `WHATSAPP_TOKEN` (token permanente de usuário do sistema) e `WHATSAPP_PHONE_NUMBER_ID`.
5. A Meta só deixa o bot iniciar conversa com modelos aprovados; **responder** dentro de 24 h do contato do cliente funciona livre.
6. Para o histórico da conversa no WhatsApp, o pacote `@netlify/blobs` (já no `package.json`) guarda as últimas mensagens.

## 4. Aviso para a equipe
Sem `NOTIFY_WEBHOOK_URL`, o orçamento só vira botão de WhatsApp para o cliente enviar. Para receber automático, crie
um webhook no Make/Zapier/n8n/Slack e cole a URL; ele recebe `{tipo, canal, nome, telefone, itens, cidade, observacoes}`.

## 5. Segurança embutida
- Chave da IA só no servidor; navegador nunca a vê.
- Aceita chamadas só do próprio domínio (`ALLOWED_ORIGINS` libera outros), limite de taxa por IP, corpo ≤ 20 KB, histórico ≤ 14 mensagens.
- Webhook do WhatsApp valida a assinatura `X-Hub-Signature-256`.
- Logs sem conteúdo de mensagens.

## 6. Antes de abrir ao público
- Preencha na Política de Privacidade o prazo de guarda e o encarregado (DPO).
- Combine com a equipe quem responde os orçamentos e em quanto tempo.
- Teste: "quero 2 inversoras" → deve pedir nome e telefone → registrar → mostrar o botão.
- Rode os testes locais: `npm test`.
- Custo: cada mensagem consome tokens; o modelo padrão (Haiku) é o mais barato. Acompanhe no console da Anthropic.
